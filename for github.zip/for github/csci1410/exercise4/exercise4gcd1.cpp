/*
This program will
find the greatest
common divisor of
two numbers
And the least 
common multiple of
two numbers
*/


//Tobby Lie

#include<iostream>

using namespace std;

//Function Prototypes

int gcd(int, int);
int lcm(int, int);

int main()
{
    //use if for menu options
    char choice;
    choice = 'a';
    while (choice != 'x' && choice != 'X')
    {
    cout << "****************" << endl;
    cout << "* Program Menu *" << endl;
    cout << "****************" << endl;
    cout << "a. Greatest Common Divisor of Two Integers" << endl;
    cout << "b. Least Common Multiple of Two Integers" << endl;
    cout << "Please input letter a or b to choose an option" << endl;
    cout << "******************************************" << endl;
    cout << "*  To exit the program, please input x   *" << endl;
    cout << "******************************************" << endl;
        
    cin >> choice;

        
    if (choice == 'a' || choice == 'A')
    {
        cout << "******************************" << endl;
        cout << "* This program will find the *" << endl;
        cout << "* greatest common divisor of *" << endl;
        cout << "* two numbers.               *" << endl;
        cout << "******************************" << endl;
        int num1, num2, greatestcd;
        cout << "Please input 2 numbers with a space separating them" << endl;
       
        
        cin >> num1 >> num2;
        
        //function call & assignment
        
        greatestcd = gcd(num1, num2);
        
        cout << "The greatest common divisor of" << endl;
        cout << num1 << " and " << num2 << endl;
        cout << " is " << greatestcd << endl;
        
        cout << endl;
        cout << endl;
    }
        
    else if (choice == 'b' || choice == 'B')
    {
        cout << "******************************" << endl;
        cout << "* This program will find the *" << endl;
        cout << "* least common multiple of   *" << endl;
        cout << "* two numbers.               *" << endl;
        cout << "******************************" << endl;
        int num1, num2, leastcm;
        
        cout << endl;
        cout << "*******************************************************" << endl;
        cout << "* Please input 2 numbers with a space separating them *" << endl;
        cout << "*******************************************************" << endl;
        cout << endl;
        
        cin >> num1 >> num2;
        
        leastcm = lcm(num1, num2);
        
        cout << "The least common multiple of" << endl;
        cout << num1 << " and " << num2 << endl;
        cout << " is " << leastcm << endl;
        
        cout << endl;
        cout << endl;
    }
    }
    
    return 0;
}
    
    //Function for gcd
int gcd (int arg1, int arg2)
{
        int count, gcd;
    for (count = 2; count <= arg1 && count <= arg2; count++)
        {
            if (arg1 % count == 0 && arg2 % count == 0)
            {
                gcd = count;
            }
        }
    return gcd;
    
}
    //Function of lcm
int lcm (int arg1, int arg2)
{
    int lcm, max;
    max = (arg1 > arg2) ? arg1 : arg2;
    do
    {
        if (max % arg1 == 0 && max % arg2 == 0)
        {
            lcm = max;
            break;
        }
        else
        {
            ++max;
        }
    }
    while (true);
    
    return lcm;
}
//last modified 2/23/17
