/*
This program will calculate a
parking fee based on a duration
of time
*/

// Tobby Lie

/*
Algorithm

-Ask user to input Entering time
in format: hh mm
-Ask user to input Exit time
in format: hh mm
-Calculate duration of time parked
-Calculate total minutes for hh of
both Entering time and Exit time
-Multiply hh of Entering and Exit
time by 60 to find total minutes in
hh
-Add that value to mm of Entering and
Exit time
-Subtract the raw total minutes of Exit
time by Entering time to find total minutes
spent parked
*/
#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>

using namespace std;

int main()

{

        int enteringHours, enteringMinutes, exitHours, exitMinutes;

        //Ask user to input Entering time
        //in hh mm format
        cout << "Please input entering time in HH MM format: " << endl;
        cin >> enteringHours >> enteringMinutes;

        //Ask user to input Exit time
        //in hh mm format
        cout << "Please input exit time in the HH MM format: " << endl;
        cin >> exitHours >> exitMinutes;

        //Calculate total duration of time parked
        //in raw minutes

        //for entering, multiply enteringHours by 60
        //then add back into value of enteringMinutes
        //define new variable for new value

        int enteringHoursMinutes;
        enteringHoursMinutes = enteringHours * 60;

        //add enteringHoursMinutes back into enteringMinutes

        int enteringRawMinutes;
        enteringRawMinutes = enteringHoursMinutes + enteringMinutes;

        //Do the same operation for raw minutes for Exit
        //multiply exitHours by 60
        //then add back to value of exitMinutes
        //define new variable for value

        int exitHoursMinutes;
        exitHoursMinutes = exitHours * 60;

        //add exitHoursMinutes back into exitMinutes

        int exitRawMinutes;
        exitRawMinutes = exitHoursMinutes + exitMinutes;

        //Subtract exitRawMinutes from enteringRawMinutes

        int durationMinutes,total_duration;
        durationMinutes = exitRawMinutes - enteringRawMinutes;
	total_duration = sqrt((pow(durationMinutes,2)));	

	//how many remaining minutes after subtracting 3 hours 
	//from the total duration? *****

	//greater than 3 hours
	int durationMore,durationLess,durationMoreRaw,durationLessRaw;
	durationMoreRaw = total_duration - 180;
	durationMore = sqrt((pow(durationMoreRaw,2)));
	
	int durationMoreDiv1, durationMoreMod1, remainingHalfHours1;
	durationMoreDiv1 = durationMore / 30;
	durationMoreMod1 = durationMore % 30;
	remainingHalfHours1 = (durationMoreMod1) - ((durationMoreMod1)-1);
	
	//less than 3 hours
	durationLessRaw = total_duration - 60;
	durationLess = sqrt((pow(durationLessRaw,2)));

	int durationLessDiv2, durationLessMod2, remainingHalfHours2;
	durationLessDiv2 = durationLess / 30;
	durationLessMod2 = durationLess % 30;
	remainingHalfHours2 = (durationLessMod2) - ((durationLessMod2)-1);

	//use if statements for greater than or less than 3 hours
	//***WORKING IF STATEMENT***
	if (total_duration > 180)
		{
		int total;
		total = 8 + (1*(remainingHalfHours1 + durationMoreDiv1));
		cout << "Total: $" << total << endl;
		}
	else if (total_duration < 180)
		{
		int total;
		total = 3 + (2*(remainingHalfHours2 + durationLessDiv2));
		cout << "Total: $" << total << endl;
		}
		
	
/*
	//how many times of 30 minutes is from the remaining minutes?

	int divisionHalfHour;
	divisionHalfHour = remainingMinutes / 30;	

	//Is there any remainder of 30 from the remaining minutes?
	//If yes what you should you do, if no what else should you do

	int remainderHalfHour,remainderHalfHour1;
	remainderHalfHour = remainingMinutes % 30;
	remainderHalfHour1 = 30 / remainderHalfHour;

	if (remainderHalfHour > 0)
		if (remainingMinutes > 180)
		{
		int total_cost;
		total_cost = 8 + (1 * (divisionHalfHour + remainderHalfHour1));
		cout << "Total: $" << total_cost << endl;
		}
		else if (remainingMinutes < 180)
		{
		int total_cost;
		total_cost = 3 + (1 * (divisionHalfHour+remainderHalfHour1));
		cout << "Total: $" << total_cost << endl;
		}
	else if (remainderHalfHour == 0)
		if (remainingMinutes > 180)
		{
		int total_cost;
		total_cost = 3 + 2 * ((divisionHalfHour + remainderHalfHour1)+4) ;
		cout << "Total: $" << total_cost << endl;
		}
		else if (remainingMinutes < 180)
		{
		int total_cost;
		total_cost = 3 + 2 * ((divisionHalfHour+4)); 
		}

*/
	/*

        //Find durationHours from durationMinutes
	//will yeild results for hours place and minutes place
	//durationHoursDivide is duration for hours place
	//durationHoursMod is duration for minutes place	

	int durationHoursDivide,durationHoursMod,extraHoursFee;
	int durationHoursDivide1,durationHoursDivide2;

	durationHoursDivide = total_duration / 60;
	durationHoursMod = total_duration % 60;
	durationHoursDivide1 = total_duration % 30;
	durationHoursDivide2 = total_duration / 30;
	
	extraHoursFee = (durationHoursDivide)*2;

	*/
/*
	totalMinutesFee = extraHoursFee + durationHoursMod;
	extraMinutesFee = totalMinutesFee / 30;
*/
	/*
	cout << extraHoursFee << endl;
	cout << "total duration" << total_duration << endl;	
	*/
	/*		
	cout << setw(2) << setfill('0') << durationHoursDivide;
	cout << setw(2) << setfill('0') << durationHoursMod << endl;
	*/

	//utilize if statement for parking fees
	/*
	if (durationHoursDivide > 3)
		{
		int total_cost;
		total_cost = 8 + 1 * ((durationHoursDivide2 - 6) + (durationHoursDivide1));	
		
		//Output total cost
		cout << "Total: " << total_cost << endl;
		}
	else if (durationHoursDivide < 3)
		{		
		int total_cost,extraMinutesFee;
		total_cost = 3 + 2 * ((durationHoursDivide2 - 2) + (durationHoursDivide1));
		
		//Output total cost
		cout << "Total: " << total_cost << endl;
		}
	*/
        return 0;
}


 
