//Programming Assignement 2
/*
This program will manage a 
bookstore. 
This program will be function-based
and use a structured data type (struct)
*/

// Tobby Lie

// last modified 3/27/17 @ 11:10AM

#include <iostream>
#include <fstream>
#include <string>
#include "header.h"

using namespace std;

int main ()
{
    const int MAX_SIZE = 100;
    int ActualSize = 0;
    
    bookstore book[MAX_SIZE];

    
    //int option;
    
  
    int option = 0;
    while (option != 7)
    {
        cout << "***************************************" << endl;
        cout << "*This program will manage a bookstore.*" << endl;
        cout << "***************************************" << endl;
        cout << "Choose an option by entering 1-7" << endl;
        
        cout << "Menu" << endl;
        cout << "------------------------------------" << endl;
        cout << "1. Read inventory from file" << endl;
        cout << "2. Show inventory" << endl;
        cout << "3. Add an entry" << endl;
        cout << "4. Delete an entry" << endl;
        cout << "5. Update an entry" << endl;
        cout << "6. Sort inventory" << endl;
        cout << "7. Write inventory to file and exit" << endl;
        
        
        cin >> option;
    
    
    
        switch (option)
        {
            case 1:
            {
                ReadInventory(book, ActualSize, MAX_SIZE);
                /*
                 By choosing this option,
                 the function ReadInventory();
                 will be called to read in txt file
                 to a struct array
                 MAX_SIZE needed to know size of array
                */
                break;
            }
        
        
            case 2:
            {
                ShowInventory(book, ActualSize);
                /*
                 ShowInventory(); will be called
                 this will display contents from 
                 struct
                */
                break;
            }
            case 3:
            {
                AddInventory(book, ActualSize, MAX_SIZE);
                /*
                 Function will be called to
                 add entry for inventory
                 */
                break;
            }
            case 4:
            {
                DeleteInventory(book, ActualSize);
                /*
                 */
                break;
            }
            case 5:
            {
                UpdateInventory(book, ActualSize);
                break;
            }
            case 6:
            {
                SortTitle(book, ActualSize);
                
                break;
            }
            case 7:
            {
                WriteInventory(book, ActualSize);
                
                break;
            }
            default:
            {
                cout << "Invalid entry!" << endl;
                cout << "Please input a number in the range of 1-7." << endl;
                break;
            }
        }
    }
    
    //int option;
    //while (option != 7);
    
    
    return 0;
}





