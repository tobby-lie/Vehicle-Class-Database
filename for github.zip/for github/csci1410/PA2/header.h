// Tobby Lie

// header file for PA2
// last modified 3/27/17 @ 11:10AM

// this file will include all functions
#include <iostream>
#include <string>
#include <fstream>

using namespace std;


struct bookstore
 {
 int ISBN;
 string Title;
 string Author;
 string Publisher;
 int Quantity;
 double Price;
 };


//Function Definitions
void ReadInventory(bookstore bookArray[], int &actualsize, int maxsize)
{
    
    ifstream inFile;
    inFile.open("inventory.txt");


    if (!inFile.fail())
    {
        //int i = 0;
        //for (int i = 0; i<maxsize; i++)
        //{
        int i = 0;
        while(inFile && i < maxsize)
        {
        //for (int i = 0; i<maxsize; i++)
        //{
            string temp;
            
            inFile >> bookArray[i].ISBN;
            getline(inFile, temp);
            //cout << bookArray[i].ISBN << endl;
            
            getline(inFile, bookArray[i].Title);
            //getline(inFile,temp);
            //cout << bookArray[i].Title << endl;
            
            getline(inFile, bookArray[i].Author);
            //getline(inFile,temp);
            //cout << bookArray[i].Author << endl;
            
            getline(inFile, bookArray[i].Publisher);
            //getline(inFile,temp);
            //cout << bookArray[i].Publisher << endl;
            
            inFile >> bookArray[i].Quantity;
            //getline(inFile,temp);
            //cout << bookArray[i].Quantity << endl;
            
            inFile >> bookArray[i].Price;
            //getline(inFile,temp);
            //cout << bookArray[i].Price << endl;
            actualsize = i;
            i++;
            
        

       // }
        
        }
       // }
        cout << endl;
        //cout << "************************************" << endl;
        cout << "*Inventory has been read from file.*" << endl;
        //cout << "************************************" << endl;
        cout << endl;
        //}
    }
    

    inFile.close();
    
    
    
    //read inventory from a file called
    //inventory.txt by using ifstream
    //to use file as input
    /*
     this will be done by using ifstream
     and reading the file into the struct array
     */
    //will need to close file after opening and reading
    
}
void ShowInventory(bookstore bookArray[], int actualsize)
{
    cout << "**************************************************" << endl;
    cout << "*The inventory info is displayed in this format: *" << endl;
    cout << "**************************************************" << endl;
    cout << endl;
    cout << "ISBN" << endl;
    cout << "Title" << endl;
    cout << "Author" << endl;
    cout << "Publisher" << endl;
    cout << "Quantity" << endl;
    cout << "Price" << endl;
    cout << endl;
    cout << endl;
    
    for (int i = 0; i<actualsize; i++)
    {
        cout << "Book: " << i+1 << endl;
        cout << "_____________" << endl;
        cout << endl;
        cout << bookArray[i].ISBN << endl;
        cout << bookArray[i].Title << endl;
        cout << bookArray[i].Author << endl;
        cout << bookArray[i].Publisher << endl;
        cout << bookArray[i].Quantity << endl;
        cout << bookArray[i].Price << endl;
        cout << endl;
        
        
    }
    //information of all books added
    //to the inventory will be
    //displayed on the screen as a string
    //will need to use ofstream to display
    //will send info from struct through
    //variable defined through ofstream
    //array needed for parameters and
    //array size also needed
}
void AddInventory(bookstore bookArray[], int &actualsize, int maxsize)
{
    cout << "This option will allow you to add a book to the inventory." << endl;
    if (actualsize++ <= maxsize)
    {
    int index;
    index = actualsize - 1;
    
    cout << endl;
    
    string temp;
    cout << "Please enter the book ISBN and hit enter: " << endl;
    cin >> bookArray[index].ISBN;
    getline(cin, temp);
    cout << endl;
    
    cout << "Please enter the book title and hit enter: " << endl;
    getline(cin,bookArray[index].Title);
    cout << endl;
    
    cout << "Please enter the book author and hit enter: " << endl;
    getline(cin,bookArray[index].Author);
    cout << endl;
    
    cout << "Please enter the book publisher and hit enter: " << endl;
    getline(cin,bookArray[index].Publisher);
    cout << endl;
    
    cout << "Please enter the book quantity and hit enter: " << endl;
    cin >> bookArray[index].Quantity;
    cout << endl;
    
    cout << "Please enter the book price and hit enter: " << endl;
    cin >> bookArray[index].Price;
    cout << endl;
        
    //actualsize += 1;
    }
    else
        cout << "Cannot add anymore books. Inventory max capacity reached." << endl;
    
    
    
    //will prompt user for each piece of info
    //and store in struct
    //after adding struct to array
    //this will call the sort option
    //This will be done by adding values
    //to the array by utilizing
    //a for loop to input info
    //about each data type in
    //bookstore struct
    
}
void DeleteInventory(bookstore bookArray[], int &actualsize)
{
    cout << "**************************************************" << endl;
    cout << "*The inventory info is displayed in this format: *" << endl;
    cout << "**************************************************" << endl;
    cout << endl;
    cout << "ISBN" << endl;
    cout << "Title" << endl;
    cout << "Author" << endl;
    cout << "Publisher" << endl;
    cout << "Quantity" << endl;
    cout << "Price" << endl;
    cout << endl;
    cout << endl;
    
    for (int i = 0; i<actualsize; i++)
    {
        cout << "Book: " << i+1 << endl;
        cout << "_____________" << endl;
        cout << endl;
        cout << bookArray[i].ISBN << endl;
        cout << bookArray[i].Title << endl;
        cout << bookArray[i].Author << endl;
        cout << bookArray[i].Publisher << endl;
        cout << bookArray[i].Quantity << endl;
        cout << bookArray[i].Price << endl;
        cout << endl;
        
        
    }
    
    cout << "Which book would you like to delete from inventory?" << endl;
    cout << "Enter the number of the book and hit enter." << endl;
    
    int choice;
    cin >> choice;
    
    if (choice <= actualsize)
    {
        for (int i = choice - 1; i <= actualsize; i++)
        {
                bookArray[i].ISBN = bookArray[i+1].ISBN;
                bookArray[i].Title = bookArray[i+1].Title;
                bookArray[i].Author = bookArray[i+1].Author;
                bookArray[i].Publisher = bookArray[i+1].Publisher;
                bookArray[i].Quantity = bookArray[i+1].Quantity;
                bookArray[i].Price = bookArray[i+1].Price;
                cout << endl;

            
        }
         actualsize -= 1;
        
        cout << endl;
        cout << "*Book " << choice << " has been deleted from inventory.*" << endl;
        cout << endl;
    }
    else
    {
        cout << endl;
        cout << "Invalid entry! book entered exceeds the number of books in inventory." << endl;
        cout << endl;
    }
        
        

    
    //display the books and ask the user
    //which book to delete
     /*will delete an entry by simply
     moving all of the entries with highter
     indexes than the deleted item back
     one slot and then decreasing the value
     size by one.*/
 

}
void UpdateInventory(bookstore bookArray[], int actualsize)
{
    cout << "**************************************************" << endl;
    cout << "*The inventory info is displayed in this format: *" << endl;
    cout << "**************************************************" << endl;
    cout << endl;
    cout << "ISBN" << endl;
    cout << "Title" << endl;
    cout << "Author" << endl;
    cout << "Publisher" << endl;
    cout << "Quantity" << endl;
    cout << "Price" << endl;
    cout << endl;
    cout << endl;
    
    for (int i = 0; i<actualsize; i++)
    {
        cout << "Book: " << i+1 << endl;
        cout << "_____________" << endl;
        cout << endl;
        cout << bookArray[i].ISBN << endl;
        cout << bookArray[i].Title << endl;
        cout << bookArray[i].Author << endl;
        cout << bookArray[i].Publisher << endl;
        cout << bookArray[i].Quantity << endl;
        cout << bookArray[i].Price << endl;
        cout << endl;
        
        
        
    }
    
    cout << "Which book would you like to update?" << endl;
    cout << "Input a the book number and hit enter." << endl;
    
    int index;
    cin >> index;
    cout << endl << endl;
    
    if (index > 0 && index <= actualsize)
    {
        cout << "This option allows you to increment, decrement or input an updated " << endl;
        cout << "quantity of your choosing, for the book you have chosen." << endl << endl;
        cout << "*Input an option (A, B or C) from the menu of options and hit enter.*" << endl;
        cout << endl;
        
        cout << "A: Increment" << endl;
        cout << "B: Decrement" << endl;
        cout << "C: Input a quantity" << endl;
        
        char choice;
        cin >> choice;
        
        if (choice == 'A' || choice == 'a')
        {
            int BookNumber;
            BookNumber = index - 1;
            bookArray[BookNumber].Quantity++;
            cout << "Book number " << index << " now has a quantity of " << bookArray[BookNumber].Quantity << endl;
        }
        else if (choice == 'B' || choice == 'b')
        {
            int BookNumber;
            BookNumber = index - 1;
            bookArray[BookNumber].Quantity--;
            cout << "Book number " << index << " now has a quantity of " << bookArray[BookNumber].Quantity << endl;
        }
        else if (choice == 'C' || choice == 'c')
        {
        int BookNumber;
        BookNumber = index - 1;
        cout << "Please input the updated quantity of this book." << endl;
        cout << "Enter a number and then hit enter." << endl;
        int NewQuantity;
        cin >> NewQuantity;
        
        bookArray[BookNumber].Quantity = NewQuantity;
        cout << "Book number " << index << " now has a quantity of " << bookArray[BookNumber].Quantity << endl;
        }
        else
            cout << "Invalid entry! Please input letter A, B or C." << endl;

    }
    else
    {
        cout << "Invalid entry! Please input the number of a book that is " << endl;
        cout << "greater than zero and less than or equal to the number of books " << endl;
        cout << "currently in inventory." << endl;
    }
    
    /*
     display the books and ask user
     which book to update
     they will give you an index number
     check to make sure they gave you a
     valid entry. You will then change the quantity
     */
}
void SortTitle(bookstore bookArray[], int actualsize)
{
    int startScan, minIndex;
    string minTitle;
    int minISBN;
    string minAuthor;
    string minPublisher;
    int minQuantity;
    int minPrice;
    
    
    for (startScan = 0; startScan < (actualsize - 1); startScan++)
    {
        minIndex = startScan;
        minISBN = bookArray[startScan].ISBN;
        minTitle = bookArray[startScan].Title;
        minAuthor = bookArray[startScan].Author;
        minPublisher = bookArray[startScan].Publisher;
        minQuantity = bookArray[startScan].Quantity;
        minPrice = bookArray[startScan].Price;
        for (int index = startScan + 1; index < actualsize; index++)
        {
            if (bookArray[index].Title < minTitle)
            {
                minTitle = bookArray[index].Title;
                minISBN = bookArray[index].ISBN;
                minAuthor = bookArray[index].Author;
                minPublisher = bookArray[index].Publisher;
                minQuantity = bookArray[index].Quantity;
                minPrice = bookArray[index].Price;
                minIndex = index;
            }
        }
        
        bookArray[minIndex].ISBN = bookArray[startScan].ISBN;
        bookArray[minIndex].Title = bookArray[startScan].Title;
        bookArray[minIndex].Author = bookArray[startScan].Author;
        bookArray[minIndex].Publisher = bookArray[startScan].Publisher;
        bookArray[minIndex].Quantity = bookArray[startScan].Quantity;
        bookArray[minIndex].Price = bookArray[startScan].Price;
        
        bookArray[startScan].ISBN = minISBN;
        bookArray[startScan].Title = minTitle;
        bookArray[startScan].Author = minAuthor;
        bookArray[startScan].Publisher = minPublisher;
        bookArray[startScan].Quantity = minQuantity;
        bookArray[startScan].Price = minPrice;
        
    }
    
    cout << endl;
    //cout << "************************************" << endl;
    cout << "*Inventory has been sorted alphabetically.*" << endl;
    //cout << "************************************" << endl;
    cout << endl;
    //}
    /*You will sort your array by title. You can use any sort algorithm that you like. Remember that your array is holding structs, so each entry in your array is a memory address that points to a struct. So when you do the move, you can simply move the entire struct.*/
    /*
     You will sort your array by title. You can use any sort algorithm
     you like
     remember you array is holding structs
     */
}
void WriteInventory(bookstore bookArray[], int actualsize)
{
    ofstream outFile;
    outFile.open("inventory.txt");
        //int i = 0;
        for (int i = 0; i<actualsize; i++)
        {
           
                //for (int i = 0; i<actualsize; i++)
                //{

                
                outFile << bookArray[i].ISBN;
            outFile << endl;
                //cout << bookArray[i].ISBN << endl;
                
                outFile << bookArray[i].Title;
            outFile << endl;
                //getline(inFile,temp);
                //cout << bookArray[i].Title << endl;
                outFile << bookArray[i].Author;
            outFile << endl;
                //getline(inFile,temp);
                //cout << bookArray[i].Author << endl;
                
                outFile << bookArray[i].Publisher;
            outFile << endl;
                //getline(inFile,temp);
                //cout << bookArray[i].Publisher << endl;
                
                outFile << bookArray[i].Quantity;
            outFile << endl;
                //getline(inFile,temp);
                //cout << bookArray[i].Quantity << endl;
                
                outFile << bookArray[i].Price;
            outFile << endl;
                //getline(inFile,temp);
                //cout << bookArray[i].Price << endl;
            
        }
        cout << endl;
        //cout << "************************************" << endl;
        cout << "*Inventory has been read to file.*" << endl;
        //cout << "************************************" << endl;
        cout << endl;
        //}
    
    
    
    outFile.close();
    
    
    
    //read inventory from a file called
    //inventory.txt by using ifstream
    //to use file as input
    /*
     this will be done by using ifstream
     and reading the file into the struct array
     */
    //will need to close file after opening and readi
    /*
     You will write the entire inventory out to a file called
     inventory.txt
     need to use ofstream to do this
     */
}
