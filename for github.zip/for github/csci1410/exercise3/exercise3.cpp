//Tobby Lie
//exercise 3 - fibonacci sequence

#include <iostream>

using namespace std;

int main ()
{
cout << "This program will output The Fibonacci sequence ";
cout << "based on the position inputted." << endl;

cout << "Please input the position within the sequence desired: " << endl;
int position;
cin >> position;

int counter, next, first, second;
first = 0;
second = 1;
for (counter=0;counter<=position;++counter)
        {
	if (counter <= 0)
		{
                next = counter;
                cout << next << endl;
        	}
	else if (counter > 0)
                {
		next = first + second;
                first = second;
                second = next;
		cout << next << endl;
        	}
	}

return 0;
}

