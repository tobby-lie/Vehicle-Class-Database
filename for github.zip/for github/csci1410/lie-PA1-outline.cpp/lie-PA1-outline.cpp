/*
Tobby Lie
Last Date Modified: 2/2/17
Assignment: Programming Assignment 1
Description: Magic Number Program
Status: Compiled and ran successfully on csegrid.ucdenver.edu 
Met all requirements 
*/

#include <iostream>
#include <string>
using namespace std;

int main()
{
	string Name, Class;

	// Present Welcome greeting and ask for first name.
	cout << "Welcome." << endl;
	cout << "What is your first name?" << endl;
	
	// user inputs first name	
	
	getline (cin,Name);	
	
	// Program asks user what class they are using program for.
	cout << endl <<  "What class are you using this program for?" << endl;

	//user inputs class name

	getline (cin,Class);

	//Present welcome message unique to user name and class

	cout << endl << Name << ", welcome to your Magic Number program. ";
	cout << "I hope it helps you with your " << Class << " class!" << endl;

	//Display menu and prompt user to input selection
	//from list of menu options
	//define char and initialize variables for a,b,c	


	char letter;
	letter = 'a';
        while (letter == 'a' || letter == 'b')
	
	{

	cout << "____________________________________" << endl;
	cout << "Please select an operation: a,b or c" << endl;
	cout << "(Type a letter from the menu and then hit return)" << endl;
	cout << 'a' << ": Display an example" << endl;
	cout << 'b' << ": Try it out yourself!" << endl;
	cout << 'c' << ": Exit" << endl;

	//After reading input, utilize the if statement
	//to execute user's chosen selection
	cin >> letter;

	if (letter == 'a')
	{
		//execution for a: Display an example
		//define int

		int n,quotientA,quotientB,remainderA,remainderB,reversedNumber;
		int hundreds,tens;

		cout << "a: Display an example!" << endl;
		cout << "__________________" << endl;
		cout << "The program will first ask you to input a number,";
		cout << " whose first digit is greater than it's last" << endl;
		
		//display input message
		cout << "The number you entered is: 792" << endl; 
		
		//display reversal message
		cout << "The reversal of the input is: 297" << endl;

		//display subtraction of reversal message
		cout << "Subtraction of reversal from the original number is: ";
		cout << "495" << endl;		
		
		//reversal of resulting number
		cout << "reversal of the resulting number is: 594" << endl;

		//addition to unreversed form
		cout << "Addition of the number to the un-reversed form is: ";
		cout << "1089" << endl;
		
		//final outcome
		cout << "The final outcome is: 1089, which is our Magic Number" << endl;

		//will need to use while() statement to reprint menu
			

	}	
	
	else if (letter == 'b')
		{
		//execution for b: Try it out yourself!
                //define int

                int n,quotientA,quotientB,remainderA,remainderB,reversedNumber;
                int hundreds,tens;

                cout << "b: Try it out yourself!" << endl;
                cout << "__________________" << endl;
                cout << "Enter a three digit integer, whose first digit is";
		cout << " greater than it's last: ";
                cin >> n;                       //ask user to input integer

                //calculations for reversing number
                /*divide input by 100, divide input by 10
                modulus input by 10, modulus quotient of n/10
                by 10 to receive all needed values for output
                of reversed number*/
                //to calculate value for reversedNumber

                quotientA = n/100;              //input divided by 100
                quotientB = n/10;               //input divided by 10
                remainderA = n%10;              //input modulus by 10
                remainderB = quotientB%10;	//quotient of n/10 modulus 10
                hundreds = remainderA * 100;    //find hundreds digit of reversedNumber
                tens = remainderB * 10;         //find tens digit of reversedNumber
                reversedNumber = hundreds + tens + quotientA;   //Calculate reversedNumber
	
		//display reversed number
		cout << "Reversal of the input is: " << reversedNumber << endl;

                int subtract;                   //define int for subtraction operation
                subtract = n - reversedNumber;  //subtract reversal from original number
		
		//display subtracted reversal
		cout << "Subtraction of reversal from the original number is: ";
		cout << subtract << endl;		

 		//calculate for second reversed number
                int quotientAA,quotientAB,remainderAA,remainderAB,hundredsA,tensA;
                int reversedNumberA;

                quotientAA = subtract/100;	//subtract result / 100
                quotientAB = subtract/10;	//subtract result / 10
                remainderAA = subtract%10;	//subtract result % 10
                remainderAB = quotientAB%10;    //quotient of subtract/10 % 10
                hundredsA = remainderAA * 100;  //find hundreds digit of reversedNumberA
                tensA = remainderAB * 10;	//find tens digit of reversedNumberA
                reversedNumberA = hundredsA + tensA + quotientAA;	//Calculate reversedNumberA


		//display second reversal
		cout << "Reversal of the resulting number is: ";
		cout << reversedNumberA << endl;

                //Add to unreversed form
                int sumreversedNumberA;         //define int for addition back into original form
                sumreversedNumberA = subtract + reversedNumberA;  //Add back to unreversed form
	
		//disply addition of number to unreversed
		cout << "Addition of the number to the un-reversed form is: ";
		cout << sumreversedNumberA << endl;

                //output final result in message

                cout << "The final outcome is: " <<  sumreversedNumberA;
                cout << " which is our Magic Number!" << endl;

                //will need to use while() loop statement to reprint menu
		
		}	
	else if (letter == 'c')
		{	
		//This part of the program will allow the user
		//to exit the program
		//will need to utilize the while() loop statement
		//to do this
		//Because c is not a true value for while statement
		//'c' allows program to exit loop
		}

		} 	

	return 0; 
}
//completed programming 1 assignment***

