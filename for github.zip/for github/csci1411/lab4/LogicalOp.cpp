// This program illustrates the use of logical operators

// Tobby Lie

#include <iostream>
using namespace std;


int main()
{
 	char year;
    float gpa;

    cout << "What year student are you ?" << endl;
    cout << "Enter 1 (freshman), 2 (sophomore), 3 (junior), or 4 (senior)" 
		 << endl << endl;
	cin >> year;

    cout << "Now enter your GPA" << endl;
    cin >> gpa;

	if (!(gpa < 2.0) && year == '4')
		{
		cout << "It is time to graduate soon" << endl;
           	}

        else if (year != '4'|| gpa <2.0)
		{
        	cout << "You need more schooling" << endl;
		}	

    return 0;	
}

/*
exercise 1:
***changed in program***
exercise 2:
You can use those operators because they are equivalent statements
exercise 3:
The students that will graduate will be the ones with a gpa 
greater than or equal to 2.0 will graduate even if they have not
gone through 4 years of schooling, also those who do not have
a gpa greater than or equal to 2.0 will still graduate if they have
gone through 4 years of schooling. This will only go to the else
if, if the student does not have a gpa greater or equal to 2.0 and 
also does not have 4 years of schooling. This does not handle all cases.
Such as a case that requires a student to both have 4 years of schooling 
AND a gpa greater than or equal to 2.0. Using an OR operator will not work
in this case, because if even one of the conditions is true, the other
will be ignored.
exercise 4:
If going off of the original program, yes because
it uses an AND statement and requires that the
student have a gpa greater than or equal to 2
AND four years of schooling. So if BOTH of those
conditions are not met, then the student will need
more schooling which trailing else statement will satisfy
If going off of the exercise 3, the student only needs to
have a gpa greater than or equal to 2 OR four years of schooling.
In this case a trailing else is not enough because
further conditions must be tested to make sure the student
has a gpa greater than or equal to 2 and also four years
of schooling.
*/
