/*
Option 1:
Program will prompt user for quarterly 
water bill for last four quarters.
This program will find and output
average monthly water bill.
*/

//Tobby Lie

#include <iostream>
#include <iomanip>

using namespace std;

int main ()
{
	cout << "Please input your water bill for quarter 1: " << endl;
	int quarter1;
	cin >> quarter1;

	cout << "Please input your water bill for quarter 2: " << endl;
	int quarter2;
	cin >> quarter2;

	cout << "Please input your water bill for quarter 3: " << endl;
	int quarter3;
	cin >> quarter3;

	cout << "Please input your water bill for quarter 4: " << endl;
	int quarter4;
	cin >> quarter4;

	float average;
	average = (float(quarter1)+quarter2+quarter3+quarter4) / 12;
	
	if (average > 75)
		{
		cout << setprecision(2) << fixed << showpoint << endl;
		cout << "Your average monthly bill is $" << average;
		cout << ". You are using too much water." << endl;
		}
	else if (average >= 25 && average <= 75)
		{
		cout << setprecision(2) << fixed << showpoint << endl;
		cout << "Your average monthly bill is $" << average;
		cout << ". You are using the typical amount of water." << endl;
		}
	else if (average < 25)
		{
		cout << setprecision(2) << fixed << showpoint << endl;
		cout << "Your average monthly bill is $" << average;
		cout << ". You are conserving water! Great job!" << endl;
		}	

return 0;
}

