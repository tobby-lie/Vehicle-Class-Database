/*
Option 1
Program will read in 3 grades from keyboard
and will print the average (to 2 decimal places)
of those grades to the screen
-Includes good prompts and labeled output
*/

/*
Algorithm
Ask user to enter in first grade
user inputs second grade 
user inputs third grade
calculate average of three grades
output the average 
use fixed with setprecision(2)
*/

// Tobby Lie

#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>

using namespace std;

int main()
{
	
	float grade1, grade2, grade3, avg;

	//ask user to input first grade
	cout << setw(25);
	cout << "Please input first grade: " << endl;
	
	//get input for first grade
	cin >> grade1;	

	//ask user to input second grade
	cout << setw(25);
	cout << "Please input second grade: " << endl;
	
	//get input for second grade
	cin >> grade2;

	//ask user to input third grade
	cout << setw(25);
	cout << "Please input third grade: " << endl;

	//get input for third grade
	cin >> grade3;

	//calculate average
	avg = ((grade1+grade2+grade3)/3);

	//display output
	cout << setprecision(2) << fixed;
	cout << "The average of the three grades is ";
	cout << avg << endl;

	return 0;
}
