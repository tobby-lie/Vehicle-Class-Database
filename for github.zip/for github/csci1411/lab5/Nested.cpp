// This program finds the average time spent programming by a student
// each day over a three day period.

// Tobby Lie

#include <iostream>
using namespace std;

int main()
{
	int numStudents;
	float numHoursPro, numHoursBio, totalBio, totalPro, averagePro, averageBio;
    int student,day = 0;     // these are the counters for the loops
	int numDays;

	cout << "This program will find the average number of hours a day" 
         << " that a student spent programming over a long weekend\n\n";
    cout << "How many students are there ?" << endl << endl;
    cin >> numStudents; 
    cout << "Enter the number of days in the long weekend"  << endl;
    cin >> numDays;
    
    //for biology
    for(student = 1; student <= numStudents; student++)
    {
		totalPro = 0;
        totalBio = 0;
		for(day = 1; day <= numDays; day++)
		{
			cout << "Please enter the number of hours worked by student " 
				 << student <<" for programming on day " << day << "." << endl;
            cin >> numHoursPro;
            
            cout << "Please enter the number of hours worked by student "
                 << student <<" for biology on day " << day << "." << endl;
            cin >> numHoursBio;

            totalPro = totalPro + numHoursPro;
            totalBio = totalBio + numHoursBio;
      
		}
        averagePro = totalPro / numDays;
        averageBio = totalBio / numDays;
        
        cout << "The average number of hours per day spent on programming" << endl;
        cout << " by student " << student << " is " << averagePro << endl;
        
        cout << "The average number of hours per day spent on biology" << endl;
        cout << " by student " << student << " is " << averageBio << endl;
        
        if (averagePro == averageBio)
        {
            cout << "Student " << student;
            cout << " spent the same amount of time on both subjects" << endl;
        }
        else if (averagePro > averageBio)
        {
            cout << "Student " << student << " on average ";
            cout << "spent more time on programming";
            cout << endl;
            
        }
        else
        {
            cout << "Student " << student << " on average ";
            cout << "spent more time on biology";
            cout << endl;
    
        }
    }
    return 0;	
}
//Completed
