//  This program has the user input a number n and then finds the
//  mean of the first n positive integers

// Tobby Lie

#include <iostream>
using namespace std;


int main()
{
	int value;       // value is some positive number n
 	int total = 0;   // total holds the sum of the first n positive numbers
   	int number;      // the amount of numbers
  	float mean;      // the average of the first n positive numbers

  	cout << "Please enter an integer" << endl;
   	cin >> value;

	cout << "Please enter the last number of the averages" << endl;
	cin >> number;

	int NumVal = (number-value)+1;

  	if (value > 0)
  	{
      	for (value; value <= number; value++)
        {
 	  	    total = total + value;
		}  // curly braces are optional since there is only one statement 
		
        mean = float(total) / NumVal;         // note the use of the typecast
		                                     // operator here
		cout << "The mean average of the first " << NumVal
             << " positive integers is " << mean << endl;
    }
    else 
        cout << "Invalid input - integer must be positive" << endl;

   return 0;	
}
/*
Exercise 1: Because in this case you are dividing two integers
which will result in an integer. But since you want a float for 
mean you have to use static_cast on total so that the end result
for mean is a float.
If it is removed, only an integer will be the result of mean even 
in the case of positive integers.
Exercise 2: Entering a float such as 2.99 will yeild a result of
1.5.
*/
//Completed
