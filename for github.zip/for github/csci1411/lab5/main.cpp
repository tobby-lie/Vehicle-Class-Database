/*
Option 1: Write a program  that performs  a survey  tally  on beverages. The
program  should  prompt  for the next person  until a sentinel value  of –1 is
entered to terminate the program. Each person  participating in the survey
should  choose  their favorite  beverage from the following list:

1. Coffee  2. Tea  3. Coke  4. Orange  Juice
*/

// Tobby Lie

#include<iostream>
#include<iomanip>
using namespace std;

int main ()
{
    cout << setw(20) << left << "Beverage Menu" << endl;
    cout << setw(20) << left << "-------------" << endl;
    cout << setw(20) << left << "1. Coffee" << endl;
    cout << setw(20) << left << "2. Tea" << endl;
    cout << setw(20) << left << "3. Coke" << endl;
    cout << setw(20) << left << "4. Orange Juice" << endl;
    
    int person = 1, choice;
    int totalcoffee=0, totaltea=0, totalcoke=0, totalorangejuice=0;
    cout << "Please input the favorite beverage of ";
    cout << "person #" << person << " : Choose 1, 2, 3, or 4 from the above ";
    cout << "menu or" << endl << "-1 to exit the program" << endl;
    cin >> choice;
    
    
    while(choice != -1)
    {
        
        if (choice == 1)
        {
            totalcoffee += 1;
        }
        else if (choice == 2)
        {
            totaltea += 1;
        }
        else if (choice == 3)
        {
            totalcoke += 1;
        }
        else if (choice == 4)
        {
            totalorangejuice += 1;
        }
        else
        {
            cout << "Invalid input" << endl;
        }

        ++person;
        cout << "Please input the favorite beverage of ";
        cout << "person #" << person << " : Choose 1, 2, 3, or 4 from the above ";
        cout << "menu or" << endl << "-1 to exit the program" << endl;
        cin >> choice;
        
    }
    
    
        //Display results of survey
        cout << "The total number of people surveyed is " << (person-1) << "." << endl;
        cout << "The results are as follows: " << endl;
        cout << setw(20) << left << "Beverage" << setw(20) << left;
        cout << "Number of Votes";
        cout << endl;
        cout << "*****************************" << endl;
        cout << setw(20) << left << "Coffee";
        cout << setw(20) << left << totalcoffee << endl;
        cout << setw(20) << left << "Tea";
        cout << setw(20) << left << totaltea << endl;
        cout << setw(20) << left << "Coke";
        cout << setw(20) << left << totalcoke << endl;
        cout << setw(20) << left << "Orange Juice";
        cout << setw(20) << left << totalorangejuice << endl;
        
    
    
    
    return 0;
}
//Completed
