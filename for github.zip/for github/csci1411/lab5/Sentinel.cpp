// This program illustrates the use of a sentinel in a while loop.
// The user is asked for monthly rainfall totals until a sentinel
// value of -1 is entered. Then the total rainfall is displayed

// Tobby Lie

#include <iostream>
using namespace std;

int main()
{
	// Fill in the code to define and initialize to 1 the variable month 
	float total = 0, rain, month = 1;

	cout << "Enter the total rainfall for month " << month << endl;
	cout << "Enter -1 when you are finished" << endl;
	// Fill in the code to read in the value for rain
	cin >> rain;
	
	// Fill in the code to start a while loop that iterates 
	// while rain does not equal -1
	while (rain != -1)
	{	
		total += rain;
		month++;
		// Fill in the code to update total by adding it to rain
		// Fill in the code to increment month by one
		
	    cout << "Enter the total rainfall in inches for month "
	         << month << endl;
		cout << "Enter -1 when you are finished" << endl;
		// Fill in the code to read in the value for rain
		cin >> rain;
	}

	if (month == 1)
		cout << "No data has been entered" << endl;

	else
		cout << "The total rainfall for the " << month-1 
		     << " months is "<< total << " inches." << endl;

	
   return 0;	
}
/*
Exercise 5: If you enter -1 first
the program states that no valid data
has been entered and the program exits.
If you enter values of 0 for one or more months
the end message displays that there was 0 inches 
of rainfall. 
Exercise 6: The purpose of if(month == 1) 
is so that if the month variable does not increment
in the while statement nothing is done to the total
which means no output will be displayed for the 
rainfall acumulated. The else is so that if the month
variable is incremented in the while statement then the
total is also adjusted.
*/
//Completed
