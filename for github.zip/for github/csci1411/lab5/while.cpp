// Tobby Lie

#include <iostream>
using namespace std;

int main()
{
	char letter = 'a';

/*    while (letter != 'x')
	{
           cout << "Please enter a letter" << endl;
           cout << "Additionally, to exit the program" << endl;
	   cout << "input the letter x." << endl;
	   cin >> letter;
           cout << "The letter you entered is " << letter << endl;
	}
*/
	//Exercise 3

	do 
	{
		cout << "Please enter a letter" << endl;
		cout << "To exit the program input the letter x." << endl;
		cin >> letter;
		cout << "The letter you entered is " << letter << endl;
	}
	while (letter != 'x');
	
    return 0;	
}

/*
Exercise 1: This program is not user 
friendly because it does not have a 
definitive end to it. One could utilize
a prompt saying to end the program, they 
would need to input 'x'.
Exercise 3: using a do-while loop will instead
always execute the statement at least once
and the condition of while is tested after 
the statement executes.
*/
//Completed
