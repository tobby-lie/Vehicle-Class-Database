//8.4

// Tobby Lie

#include <iostream>
#include <iomanip>

using namespace std;

//prototypes
void bubblesort(int array[], int size);
int binarysearch(int array[], int size, int value);
void displaysort(int [], int);
float average(int [], int size);

const int MAX_SIZE = 50;

int main()
{
    int size;
    cout << "Please enter the number of elements: " << endl;
    cin >> size;
    
    int num[MAX_SIZE];
    for (int i = 0; i < size; i++)
    {
        cout << "Please input the number for position " << i+1 << endl;
        cin >> num[i];
    }
    bubblesort(num, size);
    
    //cout << "Here is your list of numbers in ascending order." << endl;
    
    displaysort(num, size);
    
    int value;
    cout << "Enter an integer to search for: " << endl;
    cin >> value;
    
    int location = binarysearch(num, size, value);
    
    if (location == -1)
    {
        cout << "The value " << value << " is not in the list" << endl;
    }
    else
    {
            cout << "The value " << value << " is in position number "
            << location + 1 << " of the list" << endl;
    }
    float mean = average(num, size);
    cout << fixed << showpoint << setprecision(2);
    cout << "The average of the data set is " << mean << endl;
    
    
    return 0;
}
float average(int array[], int size)
{
    //need to have running total
    float total;
    for (int i = 0; i < size; i++)
    {
        total += array[i];
    }
    float average;
    average = total/size;
    return average;
}

void displaysort(int array[], int size)
{
    cout << "---------------------" << endl;
    for (int i = 0; i < size; i++)
    {
        cout << array[i] << endl;
    }
    cout << "---------------------" << endl;
}

void bubblesort(int array[], int size)
{
    //need to sort ascending order
    bool swap;
    int temp;
    
    do
    {
        swap = false;
        for (int count = 0; count < (size-1); count++)
        {
            if (array[count] > array[count+1])
            {
                temp = array[count];
                array[count] = array[count+1];
                array[count+1] = temp;
                swap = true;
                
            }
        }
    

    
    } while (swap);
}

int binarysearch(int array[], int size, int value)
{
    int first = 0;
    int last = size - 1;
    int middle;
    int position = -1;
    bool found = false;
    
    while (!found && first <= last)
    {
        middle = (first + last) / 2;
        if (array[middle]==value)
        {
            found = true;
            position = middle;
        }
        else if(array[middle]>value)
        {
            last = middle - 1;
        }
        else
        {
            first = middle + 1;
        }
    }
    return position;

}

//completed?







