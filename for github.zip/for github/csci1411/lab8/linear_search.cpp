// This program performs a linear search on a character array

// Tobby Lie

#include<iostream>
using namespace std;

int searchList( int[], int, int); // function prototype
const int SIZE = 8;

int main()
{
    int nums[SIZE] = {3,6,-19,5,5,0,-2,99};
	int found;
	int nm;
    
    nm = 1;
    while (nm != 100)
    {
            cout << "Enter an integer to search for:" << endl;
            cout << "To exit the program enter 100." << endl;
            cin >> nm;
    found = searchList(nums, SIZE, nm);
	if (found == -1)
		cout << "The integer " << nm
             << " was not found in the list" << endl;
	else
		cout << "The integer " << nm <<" is in the " << found + 1
		     << " position of the list" << endl;
    }

	return 0;

}


//*******************************************************************
//                      searchList
//
// task:	      This searches an array for a particular value
// data in:       List of values in an array, the number of 
//                elements in the array, and the value searched for
//                in the array
// data returned: Position in the array of the value or -1 if value
//                not found
//
//*******************************************************************

int searchList( int List[], int numElems, int value)
{
	for (int count = 0;count <= numElems; count++)  
	{
		if (List[count] == value)
                      // each array entry is checked to see if it contains
	                  // the desired value.
		 return count; 
                     // if the desired value is found, the array subscript
			         // count is returned to indicate the location in the array
    }
	return -1;	     // if the value is not found, -1 is returned
}

/*
Exercise 1:
 When you search for 5, because this is a linear search, it will only
 display that 5 is in the fourth position even though there are
 two 5's, one in the fourth position and one in the fifth.
Exercise 2:
 I believe both a pretest or posttest loop could work. However, I used
 a pretest loop, the while loop specifically.
*/

//completed
