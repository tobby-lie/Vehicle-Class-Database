

//Tobby Lie

/* Option 1:
 Write a program that will read scores into an array. The size of the array
 should be input by the user (dynamic array). The program will find and print 
 out the average of the scores. It will also call a function that will sort
 (using a bubble sort) the scores in ascending order. The values are then printed
 in this sorted order.
*/

#include<iostream>

using namespace std;

//prototypes
void bubblesort(int *scores, int numofScores);

int main()
{
    int *score;
    int numScores;
    int total = 0;
    
    
    cout << "Please input the number of scores" << endl;
    cin >> numScores;
    
    score = new int[numScores];
    
    if (score == NULL)
    {
        cout << "Error allocating memory!" << endl;
        return 1;
    }
    
    //get input for scores
    for (int pos = 0; pos < numScores; pos++)
    {
        cout << "Please enter a score" << endl;
        cin >> score[pos];
    }
    
    //get running total
   for (int pos = 0; pos < numScores; pos++)
    {
        total = total + score[pos];
    }
    
    int average;
    average = (total/numScores);
    
    cout << "The average of the scores is " << average << endl;
    
    cout << endl;
    
    bubblesort(score, numScores);
    
    cout << "Here are the scores in ascending order" << endl;
    
    for (int pos = 0; pos < numScores; pos++)
    {
        cout << score[pos] << endl;
        
    }
    
    delete score;
    
    return 0;
}

void bubblesort(int *scores, int numofScores)
{
    bool swap;
    int temp;
    
    do
    {
        swap = false;
        for (int count = 0; count < (numofScores-1); count ++)
        {
            if (scores[count] > scores[count+1])
            {
                temp = scores[count];
                scores[count] = scores[count+1];
                scores[count+1] = temp;
                swap = true;
            }
        }
    } while (swap);
}

//last modified 3/28/17 @ 5:42PM
//completed
