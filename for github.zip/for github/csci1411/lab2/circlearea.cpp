// This program will output the circumference and area
// of the circle with a given radius.


//  Tobby Lie

#include <iostream>
#include <cmath>
using namespace std;

const  double PI = 3.14;
const  double RADIUS = 5.4;


int main()

{
	cout << "This program will calculate and display" << endl;
	cout << "the circumference and area of a circle " << endl;
	cout << "that has a radius of 5.4." << endl;
	double area;			  	        // definition of area of circle
	
	int  circumference;				// definition of circumference
	
    circumference = 2 * PI * RADIUS;	// computes circumference
	

    area = PI * pow (RADIUS, 2);                // computes area
	
	// Fill in the code for the cout statement that will output (with description) 
	// the circumference
	cout << "The circumference of the circle is: " << circumference << endl;
	
	// Fill in the code for the cout statement that will output (with description) 
	// the area of the circle
	cout << "The area of the circle is: " << area << endl;
	
	return 0;
}
/*Lab 2.2 questions:
Circumference of the circle is 33
Area of the circle is 91.5624
*/
