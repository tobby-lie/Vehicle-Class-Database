//  This program will write the name, address and telephone 
//  number of the programmer.

//  Tobby Lie

#include <iostream>
#include <string>
using namespace std;


int main()
{

	// Fill in this space to write your first and last name
	string FirstLast;

	cout << "Please input your first and last name, " << endl;
	cout << "separated by a space, and hit enter" << endl;
	getline(cin,FirstLast);
 
	// Fill in this space to write your address (on new line)
	string address;

	cout << "Please input your address and hit enter." << endl;
	getline(cin,address);

	// Fill in this space to write you city, state and zip (on new line)
	string city;

	cout << "Please input your city and hit enter." << endl;
	getline(cin,city);

	// Fill in this space to write your telephone number (on new line)
    	string phone;
	
	cout << "Please input your telephone number and hit enter." << endl;
	getline(cin,phone);

	//Display input information

	cout << "Programmer: " << FirstLast << endl;
	cout << "            " << address << endl;
	cout << "            " << city << endl;
	cout << "Telephone: " << phone << endl;
	
	return 0;

}
