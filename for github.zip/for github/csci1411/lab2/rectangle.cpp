//this program will output the 
//perimiter and area of a rectangle

//Tobby Lie

#include <iostream>
#include <string>
#include <cmath>
using namespace std;

const double LENGTH = 8;
const double WIDTH = 3;

int main()

{
	//display message for program purpose
	cout << "This program will calculate and display" << endl;
	cout << " the perimiter and area of a rectangle." << endl;
	cout << "The length is 8 and the width is 3" << endl;
	//calculate perimiter
	double perimiter;
	perimiter = (LENGTH * 2) + (WIDTH *2);

	//calculate area
	double area;
	area = LENGTH * WIDTH;
	
	//Display results
	cout << "The perimiter is: " << perimiter << endl;
	cout << "The area is: " << area << endl;

return 0;
}
