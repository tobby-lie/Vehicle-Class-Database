/* Develop a design that leads to an algorithm
and a program that will read in a number that
represents the number of kilometers traveled.
The output will convert this number to miles.*/

// 1 kilometer = 0.621 miles

// Tobby Lie

#include <iostream>
#include <string>
using namespace std;

int main ()

{
	//prompt message asking for number of kilometers traveled

	float kilometers;
	double miles = 0.621;
	cout << "Type number of kilometers traveled";
	cout << " and then hit return." << endl; 
	cin >> kilometers;
 
	//take value for kilometers and multiply that by miles

	double milesCalculated;
	milesCalculated = kilometers * miles; 
	
	//display milesCalculated in message
	cout << endl  << "You have traveled ";
	cout  << milesCalculated << " miles." <<  endl;
	return 0;
}
