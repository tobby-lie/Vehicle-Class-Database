/*
 Option 2: Write a program  that will  input  temperatures for consecutive days.
The program  will  store these  values into an array  and call a function  that will  return  the average of the temperatures. It will  also  call a function  that will  return  the highest temperature and a function  that will  return  the lowest temperature. The user  will  input  the number of temperatures to be read. There  will  be no more  than 50 temperatures. Use typedef to declare the array  type.  The average should  be displayed to two decimal places.
 */


//Tobby Lie

#include <iostream>
#include <iomanip>

using namespace std;

const int MAXTEMP = 50;

typedef int TempType[MAXTEMP];

float average(TempType, int);
float highest(TempType, int);
float lowest(TempType, int);


int main ()
{
    TempType temp;
    int numberOfTemp;
    
    cout << "Please input the number of temperatures to be read" << endl;
    cin >> numberOfTemp;
    
    for (int pos = 0; pos < numberOfTemp; pos++)
    {
        cout << "Input temperature " << pos + 1 << endl;
        cin >> temp[pos];
    }
    float averageval;
    averageval = average(temp, numberOfTemp);
    
    cout << fixed << showpoint << setprecision(2) << endl;
    cout << "The average temperature is " << averageval << endl;
    
    float highestval;
    highestval = highest(temp, numberOfTemp);
    
    cout << fixed << showpoint << setprecision(2) << endl;
    cout << "The highest temperature is " << highestval << endl;
    
    float lowestval;
    lowestval = lowest(temp, numberOfTemp);
    
    cout << fixed << showpoint << setprecision(2) << endl;
    cout << "The lowest temperature is " << lowestval << endl;
    
    return 0;
    
}

float average(TempType temp, int size)
{
    float total = 0;
    for (int pos = 0; pos < size; pos++)
    
        total += temp[pos];
        
    
    return (total/size);

}

float highest(TempType temp, int size)
{
    float highest = temp[0];
    
    for (int pos = 0; pos < size; pos++)
    {
        if (highest < temp[pos])
            highest = temp[pos];
        
    }
    return highest;
    
    
    
    
}

float lowest(TempType temp, int size)
{
    float lowest = temp[0];
    
    for (int pos = 0; pos < size; pos++)
    {
        if (lowest > temp[pos])
            lowest = temp[pos];
        
    }
    return lowest;
    
    
    
    
}

//completed
