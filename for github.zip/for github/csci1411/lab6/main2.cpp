
// Tobby Lie

/*
 Option 1: Write a program  that will  convert  miles  to kilometers and kilometers
 to miles.  The user  will  indicate both a number (representing a distance) and a choice  of whether that number is in miles  to be converted to kilo- meters  or kilometers to be converted to miles.  Each conversion is done with a value  returning function.  You may  use the following conversions.
*/

#include<iostream>

using namespace std;

// function prototypes

float MilestoKilometers(float &num);
float KilometerstoMiles(float &num);

// global constants

float KilometertoMile = .621;
float MiletoKilometer = 1.61;

int main()

{
    
    int opt = 1;
    while (opt != 3)
    {
        cout << "Please input" << endl;
        cout << "   1 Convert miles to kilometers" << endl;
        cout << "   2 Convert kilometers to miles" << endl;
        cout << "3 Quit" << endl;
        cin >> opt;
     if (opt == 1)
     {
         float miles;
         cout << "Please input the miles ot be converted" << endl;
         cin >> miles;
         cout << miles << " miles = " << MilestoKilometers(miles);
         cout << " kilometers"<< endl;
         
     }
     else if (opt == 2)
     {
         float kilometers;
         cout << "Please input the kilometers to be converted" << endl;
         cin >> kilometers;
         cout << kilometers << " kilometers = " << KilometerstoMiles(kilometers);
         cout << " miles" << endl;
     }
    }
        
        
    return 0;
}

float MilestoKilometers(float &num)
{
    float answer;
    answer = num * MiletoKilometer;
    return answer;
}
float KilometerstoMiles(float &num)
{
    float answer;
    answer = num * KilometertoMile;
    return answer;
}
//complete




