
// Tobby Lie

// Option 1
/*
Write a program that will read two floating point
 numbers (first read into a variable called first)
 (second read into a variable called second) and 
 then calls the function swap with the actual parameters
 first and second. The swap function having formal 
 parameters number1 and number2 should swap function having
 formal parameters number 1 and number 2 should swap
 the value of the two variables. 
 Note: Similar to program in lesson set 1, logicprob.cpp
 except now using a function
*/

#include<iostream>

using namespace std;

// function prototype
void swap (int, int);

int main ()

{
    float first, second;
    
    cout << "Enter the first number: " << endl;
    cout << "Then hit enter" << endl;
    cin >> first;
    
    cout << "Enter the second number: " << endl;
    cout << "Then hit enter" << endl;
    cin >> second;
    
    cout << "You input the numbers as " << first << " and " << second << endl;
    
    swap (first, second);
    
    cout << "After swapping, the first number has the value " << endl;
    cout << "of " << first << " which was the value of the second number " << endl;
    cout << "The second number has the value of " << second << endl;
    cout << "which has the value of the first number" << endl;
    
    
    
    return 0;
}

// function definitions

void swap (int &number1, int &number2)
{
    int temp;
    temp = number1;
    number1 = number2;
    number2 = temp;
}

/*
Exercise 3:
 The swap parameters must be passed by reference
 Because main produces the output, this means that 
 the arguments passed need to be changed themselves
 rather than copies of those values. 
 Additionally, if void swap were to produce ouptut,
 in this case, pass by value would work.
*/
//complete







